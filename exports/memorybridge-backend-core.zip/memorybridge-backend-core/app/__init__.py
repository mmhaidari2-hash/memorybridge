"""MemoryBridge application package."""
